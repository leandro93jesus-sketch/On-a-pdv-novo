export interface NavItem {
  path: string;
  label: string;
  ready: boolean;
  description: string;
}

export const NAV_ITEMS: NavItem[] = [
  { path: '/vendas', label: 'Vendas', ready: true, description: 'PDV e finalização de vendas' },
  {
    path: '/historico-vendas',
    label: 'Histórico de Vendas',
    ready: true,
    description: 'Consulta, PDF, alteração e cancelamento de vendas',
  },
  {
    path: '/orcamentos',
    label: 'Orçamentos',
    ready: true,
    description: 'Propostas comerciais, PDF e conversão em venda',
  },
  { path: '/caixa', label: 'Caixa', ready: true, description: 'Abertura, sangria e fechamento' },
  {
    path: '/produtos-estoque',
    label: 'Produtos / Estoque',
    ready: true,
    description: 'Cadastro, preços, saldos e ajustes em uma tela',
  },
  { path: '/clientes', label: 'Clientes', ready: true, description: 'Cadastro de clientes' },
  { path: '/fornecedores', label: 'Fornecedores', ready: true, description: 'Cadastro de fornecedores' },
  { path: '/compras', label: 'Compras', ready: true, description: 'Entrada de mercadorias' },
  { path: '/crediario', label: 'Crediário', ready: true, description: 'Contas a receber' },
  { path: '/devolucoes', label: 'Devoluções', ready: true, description: 'Trocas e devoluções' },
  { path: '/relatorios', label: 'Relatórios', ready: true, description: 'Vendas, estoque e indicadores' },
  { path: '/entregas', label: 'Entregas', ready: true, description: 'Pedidos para entrega' },
  { path: '/backup', label: 'Backup', ready: true, description: 'Cópia, restauração e importação' },
  { path: '/configuracoes', label: 'Configurações', ready: true, description: 'Empresa, PDV, usuários e auditoria' },
];
