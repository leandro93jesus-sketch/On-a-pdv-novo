import { useEffect, useRef, useState } from 'react';
import {
  changeUserPasswordApi,
  createUserApi,
  exportDatasetApi,
  exportPrinterConfigApi,
  fetchAuditLogs,
  fetchPrintJobsApi,
  fetchPrinterPortableStatusApi,
  fetchPrinterSettings,
  fetchSettings,
  fetchSupportDiagnostics,
  fetchUsers,
  fileToBase64,
  generateDiagnosticReportApi,
  getStoredAuthUser,
  importPrinterConfigApi,
  matchPrintersApi,
  removeLogoApi,
  requeuePrintJobApi,
  resetPrinterSettingsApi,
  updatePrinterSettingsApi,
  updateSettings,
  updateUserApi,
  uploadLogoApi,
  type AppUser,
  type AuditLog,
  type LogoMeta,
  type PrintJob,
  type PrinterSettings,
  type SettingsBundle,
} from '../../api/client';
import { ModuleToolbar, StatusPill } from '../../components/ModuleChrome';
import BrandLogo from '../../components/BrandLogo';
import { withUiTimeout } from '../../lib/desktopAsync';

type Tab = 'empresa' | 'impressoras' | 'pdv' | 'usuarios' | 'auditoria' | 'suporte' | 'exportacao' | 'sobre';

const emptyUser = {
  name: '',
  login: '',
  password: '',
  role: 'operador',
  active: true,
};

export default function ConfiguracoesPage() {
  const me = getStoredAuthUser();
  const isAdmin = me?.role === 'administrador';

  const [tab, setTab] = useState<Tab>('empresa');
  const [settings, setSettings] = useState<SettingsBundle | null>(null);
  const [company, setCompany] = useState<Record<string, string>>({});
  const [pdv, setPdv] = useState<Record<string, string>>({});
  const [logo, setLogo] = useState<LogoMeta | null>(null);
  const [logoTick, setLogoTick] = useState(0);
  const [printers, setPrinters] = useState<PrinterSettings | null>(null);
  const [supportInfo, setSupportInfo] = useState<Record<string, unknown> | null>(null);
  const [diagnostic, setDiagnostic] = useState<Record<string, unknown> | null>(null);
  const [osPrinters, setOsPrinters] = useState<Array<{ name: string; displayName?: string; isDefault?: boolean }>>([]);
  const [printerNote, setPrinterNote] = useState<string | null>(null);
  const [printJobs, setPrintJobs] = useState<PrintJob[]>([]);
  const [btDevices, setBtDevices] = useState<
    Array<{ name: string; address?: string; paired?: boolean; connected?: boolean; available?: boolean }>
  >([]);
  const [btNote, setBtNote] = useState<string | null>(null);
  const [matchInfo, setMatchInfo] = useState<string | null>(null);
  const [printersLoading, setPrintersLoading] = useState(false);
  const [btLoading, setBtLoading] = useState(false);
  const [printerOpError, setPrinterOpError] = useState<string | null>(null);
  const [portableWarn, setPortableWarn] = useState<string | null>(null);
  const [linuxDiag, setLinuxDiag] = useState<Record<string, unknown> | null>(null);
  const printersGenRef = useRef(0);
  const [users, setUsers] = useState<AppUser[]>([]);
  const [audit, setAudit] = useState<AuditLog[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const [showUserForm, setShowUserForm] = useState(false);
  const [editingUser, setEditingUser] = useState<AppUser | null>(null);
  const [userForm, setUserForm] = useState(emptyUser);

  const [auditAction, setAuditAction] = useState('');
  const [auditUser, setAuditUser] = useState('');

  async function loadSettings() {
    const bundle = await fetchSettings();
    setSettings(bundle);
    setCompany({ ...(bundle.company || {}) });
    setPdv({ ...(bundle.pdv || {}) });
    setLogo(bundle.logo || null);
    setPrinters(bundle.printers || (await fetchPrinterSettings()));
  }

  async function loadOsPrinters() {
    const gen = ++printersGenRef.current;
    setPrinterOpError(null);
    setPrintersLoading(true);
    setPrinterNote('BUSCANDO IMPRESSORAS...');
    try {
      if (!window.oncaDesktop?.listPrinters) {
        if (gen !== printersGenRef.current) return;
        setOsPrinters([]);
        setPrinterNote(
          'Listagem de impressoras instaladas disponível no aplicativo desktop. As preferências abaixo serão salvas e usadas quando o desktop estiver ativo.'
        );
        return;
      }
      const res = await withUiTimeout(
        window.oncaDesktop.listPrinters(),
        10000,
        {
          printers: [],
          error: 'NÃO FOI POSSÍVEL CONSULTAR A IMPRESSORA.',
          timeout: true,
        }
      );
      if (gen !== printersGenRef.current) return;
      setOsPrinters(res.printers || []);
      if (res.error) {
        setPrinterOpError(res.error);
        setPrinterNote(res.error);
      } else {
        setPrinterNote(
          (res.printers || []).length
            ? `${res.printers.length} impressora(s) encontrada(s).`
            : 'Nenhuma impressora instalada detectada.'
        );
      }
    } catch (e) {
      if (gen !== printersGenRef.current) return;
      const msg = e instanceof Error ? e.message : 'NÃO FOI POSSÍVEL CONSULTAR A IMPRESSORA.';
      setPrinterOpError(msg);
      setPrinterNote(msg);
      setOsPrinters([]);
    } finally {
      if (gen === printersGenRef.current) setPrintersLoading(false);
    }
  }

  function cancelPrintersSearch() {
    printersGenRef.current += 1;
    setPrintersLoading(false);
    setPrinterNote('Busca cancelada.');
  }

  async function loadUsers() {
    if (!isAdmin) return;
    setUsers(await fetchUsers());
  }

  async function loadAudit() {
    if (!isAdmin) return;
    setAudit(
      await fetchAuditLogs({
        limit: 100,
        action: auditAction.trim() || undefined,
        user_name: auditUser.trim() || undefined,
      })
    );
  }

  useEffect(() => {
    void (async () => {
      try {
        // Não aguarda impressoras/Bluetooth no boot — evita travar a tela.
        await loadSettings();
        try {
          const st = await fetchPrinterPortableStatusApi();
          if (st.needs_reconfigure) {
            setPortableWarn(st.error || 'CONFIGURAÇÃO DE IMPRESSORA NÃO PÔDE SER CARREGADA.');
          }
        } catch {
          /* status opcional */
        }
        if (isAdmin) {
          await loadUsers();
          await loadAudit();
        }
        setError(null);
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Erro ao carregar configurações');
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- initial load
  }, []);

  useEffect(() => {
    if (tab === 'impressoras') {
      void loadOsPrinters();
    }
  }, [tab]);

  async function handleLogoUpload(file: File | null) {
    if (!file || !isAdmin) return;
    setBusy(true);
    setError(null);
    try {
      const b64 = await fileToBase64(file);
      const meta = await uploadLogoApi(file.name, b64);
      setLogo(meta);
      setLogoTick((n) => n + 1);
      setNotice('Logo salvo. Persistente na pasta de dados do usuário.');
      await loadSettings();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erro ao enviar logo');
    } finally {
      setBusy(false);
    }
  }

  async function handleLogoRemove() {
    if (!isAdmin) return;
    setBusy(true);
    setError(null);
    try {
      const meta = await removeLogoApi();
      setLogo(meta);
      setLogoTick((n) => n + 1);
      setNotice('Logo removido.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erro ao remover logo');
    } finally {
      setBusy(false);
    }
  }

  async function savePrinters() {
    if (!isAdmin || !printers) {
      setError('Apenas administradores podem alterar impressoras.');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const saved = await updatePrinterSettingsApi(printers);
      setPrinters(saved);
      setNotice('Configurações de impressoras salvas.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erro ao salvar impressoras');
    } finally {
      setBusy(false);
    }
  }

  async function loadPrintJobs() {
    try {
      setPrintJobs(await fetchPrintJobsApi());
    } catch {
      setPrintJobs([]);
    }
  }

  async function loadBluetooth(scan = false) {
    setBtNote(null);
    setBtLoading(true);
    try {
      if (!window.oncaDesktop?.listBluetoothDevices) {
        setBtDevices([]);
        setBtNote(
          'Bluetooth disponível no aplicativo desktop (Windows/Linux). Pareamento é feito pelo sistema operacional; o PDV lista e tenta reconhecer impressoras.'
        );
        return;
      }
      const call = scan && window.oncaDesktop.scanBluetooth
        ? window.oncaDesktop.scanBluetooth()
        : window.oncaDesktop.listBluetoothDevices();
      const res = await withUiTimeout(call, 20000, {
        devices: [],
        error: 'Busca Bluetooth expirou. Tente novamente.',
        timeout: true,
      });
      if (res.cancelled) {
        setBtNote('Busca Bluetooth cancelada.');
        return;
      }
      setBtDevices(res.devices || []);
      if (res.error) setBtNote(res.error);
      else if (!(res.devices || []).length) {
        setBtNote('Nenhum dispositivo Bluetooth listado. Use Procurar ou pareie no SO.');
      } else {
        setBtNote(`${res.devices.length} dispositivo(s) listado(s).`);
      }
    } catch (e) {
      setBtNote(e instanceof Error ? e.message : 'Falha ao listar Bluetooth');
      setBtDevices([]);
    } finally {
      setBtLoading(false);
    }
  }

  async function cancelBluetoothSearch() {
    try {
      await window.oncaDesktop?.cancelBluetooth?.();
    } catch {
      /* ignore */
    }
    setBtLoading(false);
    setBtNote('Busca Bluetooth cancelada.');
  }

  async function exportPrintersCfg() {
    try {
      const cfg = await exportPrinterConfigApi();
      const blob = new Blob([JSON.stringify(cfg, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'onca-pdv-impressoras.json';
      a.click();
      URL.revokeObjectURL(a.href);
      setNotice('Configuração exportada: onca-pdv-impressoras.json');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erro ao exportar');
    }
  }

  async function importPrintersCfg(file: File) {
    try {
      const text = await file.text();
      const json = JSON.parse(text) as Record<string, unknown>;
      const res = await importPrinterConfigApi(json);
      setPrinters(res.settings);
      setNotice(res.note || 'Configuração importada.');
      const names = osPrinters.map((p) => p.name);
      if (names.length) {
        const m = await matchPrintersApi(names);
        const missing = Object.entries(m)
          .filter(([, v]) => v.configured && !v.found)
          .map(([k, v]) => `${k}: ${v.configured}`);
        setMatchInfo(
          missing.length
            ? `IMPRESSORA CONFIGURADA NÃO ENCONTRADA. Selecione equivalente mantendo papel/perfil. Ausentes: ${missing.join('; ')}`
            : 'Impressoras configuradas reconhecidas neste computador.'
        );
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erro ao importar configuração');
    }
  }

  async function testPrint() {
    setError(null);
    setNotice(null);
    setPrinterOpError(null);
    if (!window.oncaDesktop?.testPrint) {
      setPrinterOpError(
        'Teste de impressão disponível no aplicativo desktop. A venda não é afetada por falhas de impressora.'
      );
      return;
    }
    setPrintersLoading(true);
    try {
      const deviceName = printers?.use_windows_default
        ? undefined
        : printers?.receipt_printer || printers?.default_printer || undefined;
      const res = await withUiTimeout(
        window.oncaDesktop.testPrint({
          deviceName,
          copies: printers?.profile.copies || 1,
        }),
        15000,
        { ok: false, error: 'NÃO FOI POSSÍVEL CONSULTAR A IMPRESSORA.', timeout: true }
      );
      if (!res.ok) {
        setPrinterOpError(res.error || 'Impressora indisponível. A venda não é afetada.');
      } else {
        setNotice('Teste de impressão enviado.');
      }
    } catch (e) {
      setPrinterOpError(e instanceof Error ? e.message : 'Falha no teste de impressão');
    } finally {
      setPrintersLoading(false);
    }
  }

  async function resetPrintersCfg() {
    if (!isAdmin) return;
    if (!window.confirm('Resetar apenas preferências de impressão? Produtos, vendas e caixa não serão alterados.')) {
      return;
    }
    try {
      const res = await resetPrinterSettingsApi();
      setPrinters(res.settings);
      setNotice(res.note || 'Configuração de impressão redefinida.');
      setPortableWarn(null);
      setMatchInfo(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erro ao resetar impressão');
    }
  }

  async function saveSettings(section: 'company' | 'pdv') {
    if (!isAdmin) {
      setError('Apenas administradores podem alterar configurações.');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const payload =
        section === 'company' ? { company } : { pdv };
      const bundle = await updateSettings(payload);
      setSettings(bundle);
      setCompany({ ...(bundle.company || {}) });
      setPdv({ ...(bundle.pdv || {}) });
      setNotice('Configurações salvas.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erro ao salvar');
    } finally {
      setBusy(false);
    }
  }

  function openCreateUser() {
    setEditingUser(null);
    setUserForm(emptyUser);
    setShowUserForm(true);
  }

  function openEditUser(u: AppUser) {
    setEditingUser(u);
    setUserForm({
      name: u.name,
      login: u.login,
      password: '',
      role: u.role,
      active: Boolean(u.active),
    });
    setShowUserForm(true);
  }

  async function saveUser() {
    if (!userForm.name.trim() || !userForm.login.trim()) {
      setError('Nome e login são obrigatórios');
      return;
    }
    if (!editingUser && !userForm.password) {
      setError('Senha é obrigatória para novo usuário');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      if (editingUser) {
        await updateUserApi(editingUser.id, {
          name: userForm.name.trim(),
          role: userForm.role,
          active: userForm.active,
        });
        if (userForm.password) {
          await changeUserPasswordApi(editingUser.id, userForm.password);
        }
        setNotice('Usuário atualizado.');
      } else {
        await createUserApi({
          name: userForm.name.trim(),
          login: userForm.login.trim(),
          password: userForm.password,
          role: userForm.role,
        });
        setNotice('Usuário criado.');
      }
      setShowUserForm(false);
      await loadUsers();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erro ao salvar usuário');
    } finally {
      setBusy(false);
    }
  }

  function setCompanyField(key: string, value: string) {
    setCompany((prev) => ({ ...prev, [key]: value }));
  }

  function setPdvField(key: string, value: string) {
    setPdv((prev) => ({ ...prev, [key]: value }));
  }

  function boolField(value: string | undefined): boolean {
    return value === '1' || value === 'true' || value === 'yes';
  }

  return (
    <section className="module-panel">
      <div className="tabs" role="tablist">
        {(
          [
            ['empresa', 'Empresa'],
            ['impressoras', 'Impressoras'],
            ['pdv', 'PDV'],
            ['usuarios', 'Usuários'],
            ['auditoria', 'Auditoria'],
            ['exportacao', 'Exportar dados'],
            ['suporte', 'Suporte'],
            ['sobre', 'Sobre'],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            className={`tab${tab === id ? ' active' : ''}`}
            onClick={() => setTab(id)}
          >
            {label}
          </button>
        ))}
      </div>

      {error && <div className="alert alert-error">{error}</div>}
      {notice && <div className="alert alert-ok">{notice}</div>}

      {tab === 'empresa' && (
        <>
          <div className="side-card" style={{ marginBottom: 16 }}>
            <h3>Logo oficial da loja</h3>
            <p className="muted-line">
              PNG, JPG, JPEG ou WEBP. Salvo na pasta de dados do usuário (não é apagado em
              atualizações). Sem logo oficial, permanece a marca ON.
            </p>
            <div style={{ display: 'flex', gap: 16, alignItems: 'center', marginTop: 12 }}>
              <BrandLogo key={logoTick} size={72} />
              <div className="modal-fields" style={{ flex: 1 }}>
                <label>
                  Selecionar logo
                  <input
                    type="file"
                    accept=".png,.jpg,.jpeg,.webp,image/png,image/jpeg,image/webp"
                    disabled={!isAdmin || busy}
                    onChange={(e) => void handleLogoUpload(e.target.files?.[0] || null)}
                  />
                </label>
                <div className="modal-actions" style={{ justifyContent: 'flex-start' }}>
                  <button
                    type="button"
                    className="btn btn-ghost"
                    disabled={!isAdmin || busy || !logo?.has_logo}
                    onClick={() => void handleLogoRemove()}
                  >
                    Remover logo
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="form-grid">
            <label className="span-2">
              Nome da loja
              <input
                className="field-input"
                value={company.store_name || ''}
                onChange={(e) => setCompanyField('store_name', e.target.value)}
              />
            </label>
            <label className="span-2">
              Nome fantasia
              <input
                className="field-input"
                value={company.store_trade_name || ''}
                onChange={(e) => setCompanyField('store_trade_name', e.target.value)}
              />
            </label>
            <label>
              CNPJ / documento
              <input
                className="field-input"
                value={company.store_document || ''}
                onChange={(e) => setCompanyField('store_document', e.target.value)}
              />
            </label>
            <label>
              Telefone
              <input
                className="field-input"
                value={company.store_phone || ''}
                onChange={(e) => setCompanyField('store_phone', e.target.value)}
              />
            </label>
            <label>
              WhatsApp
              <input
                className="field-input"
                value={company.store_whatsapp || ''}
                onChange={(e) => setCompanyField('store_whatsapp', e.target.value)}
              />
            </label>
            <label>
              Site
              <input
                className="field-input"
                value={company.store_site || ''}
                onChange={(e) => setCompanyField('store_site', e.target.value)}
              />
            </label>
            <label className="span-2">
              Endereço
              <input
                className="field-input"
                value={company.store_address || ''}
                onChange={(e) => setCompanyField('store_address', e.target.value)}
              />
            </label>
            <label className="span-2">
              Instagram
              <input
                className="field-input"
                value={company.store_instagram || ''}
                onChange={(e) => setCompanyField('store_instagram', e.target.value)}
              />
            </label>
            <label className="span-2">
              Mensagem do comprovante
              <input
                className="field-input"
                value={company.receipt_message || ''}
                onChange={(e) => setCompanyField('receipt_message', e.target.value)}
              />
            </label>
          </div>
          <div className="modal-actions" style={{ justifyContent: 'flex-start', marginTop: 12 }}>
            <button
              type="button"
              className="btn btn-primary"
              disabled={busy || !isAdmin}
              onClick={() => void saveSettings('company')}
            >
              Salvar empresa
            </button>
            {!isAdmin && (
              <span className="muted-line">Somente administradores podem salvar.</span>
            )}
          </div>
        </>
      )}

      {tab === 'impressoras' && printers && (
        <>
          {portableWarn && (
            <div className="alert alert-error" style={{ marginBottom: 12 }}>
              {portableWarn}
              <div style={{ marginTop: 8 }}>
                <button type="button" className="btn btn-primary" onClick={() => setPortableWarn(null)}>
                  Reconfigurar
                </button>
              </div>
            </div>
          )}
          {printerOpError && (
            <div className="alert alert-error" style={{ marginBottom: 12 }}>
              {printerOpError}
              <div className="modal-actions" style={{ justifyContent: 'flex-start', marginTop: 8 }}>
                <button type="button" className="btn btn-accent" onClick={() => void loadOsPrinters()}>
                  Tentar novamente
                </button>
                <button type="button" className="btn btn-ghost" onClick={() => setPrinterOpError(null)}>
                  Fechar
                </button>
              </div>
            </div>
          )}
          {printersLoading && (
            <div className="alert alert-ok" style={{ marginBottom: 12 }}>
              BUSCANDO IMPRESSORAS...
              <div style={{ marginTop: 8 }}>
                <button type="button" className="btn btn-ghost" onClick={cancelPrintersSearch}>
                  Cancelar
                </button>
              </div>
            </div>
          )}
          <p className="muted-line" style={{ marginBottom: 12 }}>
            {printerNote || printers.note}
          </p>
          <div className="form-grid">
            <label className="check-inline span-2">
              <input
                type="checkbox"
                checked={printers.use_windows_default}
                disabled={!isAdmin}
                onChange={(e) =>
                  setPrinters({ ...printers, use_windows_default: e.target.checked })
                }
              />
              Usar impressora padrão do Windows
            </label>
            <label>
              Impressora de comprovante
              <select
                className="field-input"
                disabled={!isAdmin || printers.use_windows_default}
                value={printers.receipt_printer}
                onChange={(e) => setPrinters({ ...printers, receipt_printer: e.target.value })}
              >
                <option value="">— padrão / não definida —</option>
                {osPrinters.map((p) => (
                  <option key={p.name} value={p.name}>
                    {p.displayName || p.name}
                    {p.isDefault ? ' (padrão Windows)' : ''}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Impressora de relatórios
              <select
                className="field-input"
                disabled={!isAdmin || printers.use_windows_default}
                value={printers.reports_printer}
                onChange={(e) => setPrinters({ ...printers, reports_printer: e.target.value })}
              >
                <option value="">— padrão / não definida —</option>
                {osPrinters.map((p) => (
                  <option key={`r-${p.name}`} value={p.name}>
                    {p.displayName || p.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Impressora de pedidos/entregas
              <select
                className="field-input"
                disabled={!isAdmin || printers.use_windows_default}
                value={printers.delivery_printer || ''}
                onChange={(e) => setPrinters({ ...printers, delivery_printer: e.target.value })}
              >
                <option value="">— padrão / não definida —</option>
                {osPrinters.map((p) => (
                  <option key={`e-${p.name}`} value={p.name}>
                    {p.displayName || p.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Impressora padrão do ONÇA PDV
              <select
                className="field-input"
                disabled={!isAdmin || printers.use_windows_default}
                value={printers.default_printer}
                onChange={(e) => setPrinters({ ...printers, default_printer: e.target.value })}
              >
                <option value="">— padrão Windows —</option>
                {osPrinters.map((p) => (
                  <option key={`d-${p.name}`} value={p.name}>
                    {p.displayName || p.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Formato
              <select
                className="field-input"
                disabled={!isAdmin}
                value={printers.profile.format}
                onChange={(e) =>
                  setPrinters({
                    ...printers,
                    profile: { ...printers.profile, format: e.target.value },
                  })
                }
              >
                <option value="A4">A4</option>
                <option value="80mm">80 mm</option>
                <option value="58mm">58 mm</option>
              </select>
            </label>
            <label>
              Cópias
              <input
                className="field-input"
                type="number"
                min={1}
                max={10}
                disabled={!isAdmin}
                value={printers.profile.copies}
                onChange={(e) =>
                  setPrinters({
                    ...printers,
                    profile: { ...printers.profile, copies: Number(e.target.value) || 1 },
                  })
                }
              />
            </label>
            <label>
              Modo
              <select
                className="field-input"
                disabled={!isAdmin}
                value={printers.profile.mode}
                onChange={(e) =>
                  setPrinters({
                    ...printers,
                    profile: { ...printers.profile, mode: e.target.value },
                  })
                }
              >
                <option value="manual">Impressão manual</option>
                <option value="auto">Impressão automática</option>
              </select>
            </label>
            <label className="check-inline span-2">
              <input
                type="checkbox"
                disabled={!isAdmin}
                checked={printers.profile.auto_print}
                onChange={(e) =>
                  setPrinters({
                    ...printers,
                    profile: { ...printers.profile, auto_print: e.target.checked },
                  })
                }
              />
              Impressão automática quando aplicável
            </label>
          </div>
          <div className="modal-actions" style={{ justifyContent: 'flex-start', marginTop: 12 }}>
            <button
              type="button"
              className="btn btn-primary"
              disabled={busy || !isAdmin}
              onClick={() => void savePrinters()}
            >
              Salvar impressoras
            </button>
            <button
              type="button"
              className="btn btn-accent"
              disabled={busy}
              onClick={() => void testPrint()}
            >
              Testar impressão
            </button>
            <button
              type="button"
              className="btn btn-ghost"
              disabled={printersLoading}
              onClick={() => void loadOsPrinters()}
            >
              Atualizar lista
            </button>
            <button
              type="button"
              className="btn btn-danger"
              disabled={busy || !isAdmin || printersLoading}
              onClick={() => void resetPrintersCfg()}
            >
              Resetar configuração de impressão
            </button>
            <button
              type="button"
              className="btn btn-ghost"
              disabled={busy || !isAdmin}
              onClick={() => void exportPrintersCfg()}
            >
              Exportar configuração
            </button>
            <label className="btn btn-ghost" style={{ cursor: isAdmin ? 'pointer' : 'not-allowed' }}>
              Importar configuração
              <input
                type="file"
                accept="application/json,.json"
                disabled={!isAdmin || busy}
                style={{ display: 'none' }}
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void importPrintersCfg(f);
                  e.target.value = '';
                }}
              />
            </label>
          </div>
          {matchInfo && <div className="alert alert-error" style={{ marginTop: 12 }}>{matchInfo}</div>}
          <p className="muted-line" style={{ marginTop: 12 }}>
            Se a impressora estiver desligada, a venda concluída não é cancelada nem travada — apenas
            uma mensagem clara é exibida. Configuração portátil: configuracoes/impressoras.json.
          </p>

          <div className="side-card" style={{ marginTop: 16 }}>
            <h3>Fila de impressão</h3>
            <div className="modal-actions" style={{ justifyContent: 'flex-start' }}>
              <button type="button" className="btn btn-ghost" onClick={() => void loadPrintJobs()}>
                Atualizar fila
              </button>
            </div>
            {printJobs.length === 0 ? (
              <p className="muted-line">Nenhum trabalho listado. Clique em Atualizar fila.</p>
            ) : (
              <table className="data-table" style={{ marginTop: 8 }}>
                <thead>
                  <tr>
                    <th>Doc</th>
                    <th>Impressora</th>
                    <th>Status</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {printJobs.slice(0, 30).map((j) => (
                    <tr key={j.id}>
                      <td>
                        {j.title}
                        <div className="muted-line">{j.document_type}</div>
                      </td>
                      <td>{j.printer_name || '—'}</td>
                      <td>{j.status}</td>
                      <td>
                        {(j.status === 'erro' || j.status === 'pendente') && isAdmin && (
                          <button
                            type="button"
                            className="btn btn-ghost"
                            onClick={() =>
                              void requeuePrintJobApi(j.id).then(() => loadPrintJobs())
                            }
                          >
                            Reimprimir
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          <div className="side-card" style={{ marginTop: 16 }}>
            <h3>Bluetooth</h3>
            <p className="muted-line">
              Dispositivo pareado ≠ impressora pronta. Só use para impressão quando houver fila de
              impressão válida no sistema.
            </p>
            {btNote && <p className="muted-line">{btNote}</p>}
            {btLoading && (
              <div className="alert alert-ok" style={{ marginBottom: 8 }}>
                Buscando dispositivos Bluetooth...
                <div style={{ marginTop: 8 }}>
                  <button type="button" className="btn btn-ghost" onClick={() => void cancelBluetoothSearch()}>
                    Cancelar
                  </button>
                </div>
              </div>
            )}
            <div className="modal-actions" style={{ justifyContent: 'flex-start' }}>
              <button
                type="button"
                className="btn btn-ghost"
                disabled={btLoading}
                onClick={() => void loadBluetooth(false)}
              >
                Atualizar
              </button>
              <button
                type="button"
                className="btn btn-ghost"
                disabled={btLoading}
                onClick={() => void loadBluetooth(true)}
              >
                Procurar
              </button>
            </div>
            {btDevices.length > 0 && (
              <table className="data-table" style={{ marginTop: 8 }}>
                <thead>
                  <tr>
                    <th>Nome</th>
                    <th>Identificador</th>
                    <th>Pareado</th>
                    <th>Conectado</th>
                    <th>Disponível</th>
                    <th>Impressora</th>
                  </tr>
                </thead>
                <tbody>
                  {btDevices.map((d) => {
                    const installed = osPrinters.some(
                      (p) =>
                        p.name.toLowerCase().includes((d.name || '').toLowerCase()) ||
                        (d.name || '').toLowerCase().includes(p.name.toLowerCase())
                    );
                    return (
                      <tr key={`${d.name}-${d.address || ''}`}>
                        <td>{d.name}</td>
                        <td>{d.address || '—'}</td>
                        <td>{d.paired ? 'Sim' : 'Não'}</td>
                        <td>{d.connected ? 'Sim' : 'Não'}</td>
                        <td>{d.available ? 'Sim' : 'Não'}</td>
                        <td>{installed ? 'INSTALADA' : 'NÃO INSTALADA'}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </>
      )}

      {tab === 'exportacao' && (
        <div className="side-card">
          <h3>Exportar dados (emergência)</h3>
          <p className="muted-line">Formato CSV. Não inclui senhas.</p>
          {!isAdmin ? (
            <div className="alert alert-error">Somente administrador.</div>
          ) : (
            <div className="form-grid">
              {['products', 'stock', 'customers', 'sales', 'credit'].map((ds) => (
                <button
                  key={ds}
                  type="button"
                  className="btn btn-primary"
                  disabled={busy}
                  onClick={() =>
                    void (async () => {
                      try {
                        setBusy(true);
                        const file = await exportDatasetApi(ds);
                        const blob = new Blob([file.content], { type: file.mime });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = file.filename;
                        a.click();
                        URL.revokeObjectURL(url);
                        setNotice(`Exportado ${ds}: ${file.rows} linha(s).`);
                      } catch (e) {
                        setError(e instanceof Error ? e.message : 'Erro na exportação');
                      } finally {
                        setBusy(false);
                      }
                    })()
                  }
                >
                  Exportar {ds}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'suporte' && (
        <div className="side-card">
          <h3>Modo suporte</h3>
          {!isAdmin ? (
            <div className="alert alert-error">Somente administrador.</div>
          ) : (
            <>
              <ModuleToolbar>
                <button
                  type="button"
                  className="btn btn-ghost"
                  disabled={busy}
                  onClick={() =>
                    void (async () => {
                      try {
                        const info = await fetchSupportDiagnostics();
                        setSupportInfo(info);
                        setLinuxDiag(
                          (info.linux_print as Record<string, unknown>) ||
                            (info.os as Record<string, unknown>) ||
                            null
                        );
                        if (window.oncaDesktop?.getLinuxPrintDiag) {
                          try {
                            const desk = await withUiTimeout(
                              window.oncaDesktop.getLinuxPrintDiag(),
                              15000,
                              { error: 'Timeout no diagnóstico desktop Linux.' }
                            );
                            setLinuxDiag((prev) => ({ ...(prev || {}), desktop: desk }));
                          } catch {
                            /* desktop opcional */
                          }
                        }
                      } catch (e) {
                        setError(e instanceof Error ? e.message : 'Erro no diagnóstico');
                      }
                    })()
                  }
                >
                  Atualizar diagnóstico
                </button>
                <button
                  type="button"
                  className="btn btn-primary"
                  disabled={busy}
                  onClick={() =>
                    void (async () => {
                      try {
                        const report = await generateDiagnosticReportApi();
                        setDiagnostic(report);
                        setNotice('Relatório de diagnóstico gerado (sem senhas).');
                      } catch (e) {
                        setError(e instanceof Error ? e.message : 'Erro ao gerar relatório');
                      }
                    })()
                  }
                >
                  Gerar relatório de diagnóstico
                </button>
              </ModuleToolbar>

              <div className="side-card" style={{ marginTop: 12 }}>
                <h3>LINUX / IMPRESSÃO</h3>
                <p className="muted-line">
                  Diagnóstico do host. Bluetooth pareado ≠ impressora CUPS pronta.
                </p>
                {linuxDiag ? (
                  <div className="kv-list">
                    <div>
                      <span>Sistema operacional</span>
                      <strong>
                        {String(
                          (linuxDiag as { platform?: string }).platform ||
                            window.oncaDesktop?.platform ||
                            '—'
                        )}
                      </strong>
                    </div>
                    <div>
                      <span>Distribuição</span>
                      <strong>{String((linuxDiag as { distribution?: string }).distribution || '—')}</strong>
                    </div>
                    <div>
                      <span>Arquitetura</span>
                      <strong>{String((linuxDiag as { arch?: string }).arch || '—')}</strong>
                    </div>
                    <div>
                      <span>CUPS</span>
                      <strong>
                        {String(
                          ((linuxDiag as { cups?: { message?: string } }).cups?.message) ||
                            ((linuxDiag as { desktop?: { cups?: { message?: string } } }).desktop?.cups
                              ?.message) ||
                            '—'
                        )}
                      </strong>
                    </div>
                    <div>
                      <span>lpstat</span>
                      <strong>
                        {(linuxDiag as { cups?: { lpstat?: boolean } }).cups?.lpstat
                          ? 'DISPONÍVEL'
                          : 'INDISPONÍVEL'}
                      </strong>
                    </div>
                    <div>
                      <span>Bluetooth (bluetoothctl)</span>
                      <strong>{String((linuxDiag as { bluetoothctl?: string }).bluetoothctl || '—')}</strong>
                    </div>
                    <div>
                      <span>Electron getPrintersAsync</span>
                      <strong>
                        {(() => {
                          const desk = (linuxDiag as { desktop?: { electron_getPrintersAsync?: { ok?: boolean; count?: number; error?: string } } }).desktop
                            ?.electron_getPrintersAsync;
                          if (!desk) return '— (abra no desktop Linux)';
                          return desk.ok ? `OK (${desk.count})` : `FALHA${desk.error ? `: ${desk.error}` : ''}`;
                        })()}
                      </strong>
                    </div>
                    <div>
                      <span>Impressoras (CUPS)</span>
                      <strong>
                        {String(
                          (linuxDiag as { cups?: { printers_count?: number } }).cups?.printers_count ??
                            (linuxDiag as { desktop?: { printers_count?: number } }).desktop?.printers_count ??
                            '—'
                        )}
                      </strong>
                    </div>
                    <div>
                      <span>Impressora padrão</span>
                      <strong>
                        {String(
                          (linuxDiag as { cups?: { default_printer?: string | null } }).cups
                            ?.default_printer ||
                            (linuxDiag as { desktop?: { default_printer?: string | null } }).desktop
                              ?.default_printer ||
                            '—'
                        )}
                      </strong>
                    </div>
                  </div>
                ) : (
                  <p className="muted-line">Clique em Atualizar diagnóstico.</p>
                )}
              </div>

              <pre className="code-block" style={{ maxHeight: 360, overflow: 'auto', marginTop: 12 }}>
                {JSON.stringify(diagnostic || supportInfo || { tip: 'Clique em atualizar diagnóstico' }, null, 2)}
              </pre>
            </>
          )}
        </div>
      )}

      {tab === 'sobre' && (
        <div className="side-card">
          <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
            <BrandLogo key={`sobre-${logoTick}`} size={80} />
            <div>
              <h3>ONÇA PDV</h3>
              <p className="muted-line">ONÇA Produtos de Limpeza</p>
              <div className="kv-list" style={{ marginTop: 12 }}>
                <div>
                  <span>Versão</span>
                  <strong>{settings?.app_version || '1.0.0'}</strong>
                </div>
                <div>
                  <span>Logo</span>
                  <strong>{logo?.has_logo ? 'Configurado' : 'Marca padrão (ON)'}</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {tab === 'pdv' && (
        <>
          <div className="form-grid">
            <label>
              Terminal
              <input
                className="field-input"
                value={pdv.terminal_id || ''}
                onChange={(e) => setPdvField('terminal_id', e.target.value)}
              />
            </label>
            <label>
              Operador padrão
              <input
                className="field-input"
                value={pdv.current_operator || ''}
                onChange={(e) => setPdvField('current_operator', e.target.value)}
              />
            </label>
            <label>
              Escala da UI
              <input
                className="field-input"
                value={pdv.ui_scale || ''}
                onChange={(e) => setPdvField('ui_scale', e.target.value)}
              />
            </label>
            <label>
              Pasta de backup
              <input
                className="field-input"
                value={pdv.backup_dir || ''}
                onChange={(e) => setPdvField('backup_dir', e.target.value)}
              />
            </label>
            <label className="span-2">
              Mensagem padrão WhatsApp
              <input
                className="field-input"
                value={pdv.whatsapp_default_message || ''}
                onChange={(e) => setPdvField('whatsapp_default_message', e.target.value)}
              />
            </label>
            <label className="check-inline span-2">
              <input
                type="checkbox"
                checked={boolField(pdv.cash_require_open)}
                onChange={(e) => setPdvField('cash_require_open', e.target.checked ? '1' : '0')}
              />
              Exigir caixa aberto para vender
            </label>
            <label className="check-inline span-2">
              <input
                type="checkbox"
                checked={boolField(pdv.sale_allow_misc)}
                onChange={(e) => setPdvField('sale_allow_misc', e.target.checked ? '1' : '0')}
              />
              Permitir item diversos
            </label>
            <label className="check-inline span-2">
              <input
                type="checkbox"
                checked={boolField(pdv.print_auto_open)}
                onChange={(e) => setPdvField('print_auto_open', e.target.checked ? '1' : '0')}
              />
              Abrir comprovante automaticamente
            </label>
            <label className="check-inline span-2">
              <input
                type="checkbox"
                checked={boolField(pdv.allow_negative_stock_global)}
                onChange={(e) =>
                  setPdvField('allow_negative_stock_global', e.target.checked ? '1' : '0')
                }
              />
              Permitir estoque negativo (global)
            </label>
            {settings?.app_version ? (
              <p className="muted-line span-2">Versão do app: {settings.app_version}</p>
            ) : null}
          </div>
          <div className="modal-actions" style={{ justifyContent: 'flex-start', marginTop: 12 }}>
            <button
              type="button"
              className="btn btn-primary"
              disabled={busy || !isAdmin}
              onClick={() => void saveSettings('pdv')}
            >
              Salvar PDV
            </button>
          </div>
        </>
      )}

      {tab === 'usuarios' && (
        <>
          {!isAdmin ? (
            <p className="cart-empty">Acesso restrito a administradores.</p>
          ) : (
            <>
              <ModuleToolbar>
                <button type="button" className="btn btn-primary" onClick={openCreateUser}>
                  Novo usuário
                </button>
                <button
                  type="button"
                  className="btn btn-ghost"
                  onClick={() => void loadUsers().catch((e) => setError(e.message))}
                >
                  Atualizar
                </button>
              </ModuleToolbar>
              <div className="product-table-wrap">
                <table className="product-table">
                  <thead>
                    <tr>
                      <th>Nome</th>
                      <th>Login</th>
                      <th>Perfil</th>
                      <th>Status</th>
                      <th>Último acesso</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((u) => (
                      <tr key={u.id}>
                        <td>{u.name}</td>
                        <td>{u.login}</td>
                        <td>{u.role}</td>
                        <td>
                          <StatusPill tone={u.active ? 'ok' : 'muted'}>
                            {u.active ? 'Ativo' : 'Inativo'}
                          </StatusPill>
                        </td>
                        <td>{u.last_login_at || '—'}</td>
                        <td className="row-actions">
                          <button
                            type="button"
                            className="btn btn-ghost"
                            onClick={() => openEditUser(u)}
                          >
                            Editar
                          </button>
                        </td>
                      </tr>
                    ))}
                    {users.length === 0 && (
                      <tr>
                        <td colSpan={6}>Nenhum usuário.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </>
      )}

      {tab === 'auditoria' && (
        <>
          {!isAdmin ? (
            <p className="cart-empty">Acesso restrito a administradores.</p>
          ) : (
            <>
              <ModuleToolbar>
                <input
                  className="search-input"
                  placeholder="Filtrar ação…"
                  value={auditAction}
                  onChange={(e) => setAuditAction(e.target.value)}
                />
                <input
                  className="search-input"
                  placeholder="Filtrar usuário…"
                  value={auditUser}
                  onChange={(e) => setAuditUser(e.target.value)}
                />
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={() =>
                    void loadAudit().catch((e) =>
                      setError(e instanceof Error ? e.message : 'Erro na auditoria')
                    )
                  }
                >
                  Filtrar
                </button>
              </ModuleToolbar>
              <div className="product-table-wrap">
                <table className="product-table">
                  <thead>
                    <tr>
                      <th>Quando</th>
                      <th>Ação</th>
                      <th>Usuário</th>
                      <th>Entidade</th>
                      <th>Resultado</th>
                      <th>Detalhes</th>
                    </tr>
                  </thead>
                  <tbody>
                    {audit.map((a) => (
                      <tr key={a.id}>
                        <td>{a.created_at}</td>
                        <td>{a.action}</td>
                        <td>{a.user_name || '—'}</td>
                        <td>
                          {a.entity_type || '—'}
                          {a.entity_id != null ? ` #${a.entity_id}` : ''}
                        </td>
                        <td>
                          <StatusPill
                            tone={
                              a.result === 'fail' || a.result === 'error' ? 'danger' : 'ok'
                            }
                          >
                            {a.result || 'ok'}
                          </StatusPill>
                        </td>
                        <td className="muted-line">
                          {typeof a.details === 'string'
                            ? a.details
                            : a.details
                              ? JSON.stringify(a.details)
                              : '—'}
                        </td>
                      </tr>
                    ))}
                    {audit.length === 0 && (
                      <tr>
                        <td colSpan={6}>Sem registros.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </>
      )}

      {showUserForm && (
        <div className="modal-backdrop">
          <div className="modal">
            <h3>{editingUser ? 'Editar usuário' : 'Novo usuário'}</h3>
            <div className="form-grid">
              <label className="span-2">
                Nome *
                <input
                  className="field-input"
                  value={userForm.name}
                  onChange={(e) => setUserForm({ ...userForm, name: e.target.value })}
                />
              </label>
              <label>
                Login *
                <input
                  className="field-input"
                  value={userForm.login}
                  onChange={(e) => setUserForm({ ...userForm, login: e.target.value })}
                />
              </label>
              <label>
                Perfil
                <select
                  className="field-input"
                  value={userForm.role}
                  onChange={(e) => setUserForm({ ...userForm, role: e.target.value })}
                >
                  <option value="operador">Operador</option>
                  <option value="administrador">Administrador</option>
                </select>
              </label>
              <label className="span-2">
                {editingUser ? 'Nova senha (opcional)' : 'Senha *'}
                <input
                  className="field-input"
                  type="password"
                  value={userForm.password}
                  onChange={(e) => setUserForm({ ...userForm, password: e.target.value })}
                />
              </label>
              {editingUser ? (
                <label className="check-inline span-2">
                  <input
                    type="checkbox"
                    checked={userForm.active}
                    onChange={(e) => setUserForm({ ...userForm, active: e.target.checked })}
                  />
                  Ativo
                </label>
              ) : null}
            </div>
            <div className="modal-actions">
              <button type="button" className="btn btn-ghost" onClick={() => setShowUserForm(false)}>
                Cancelar
              </button>
              <button
                type="button"
                className="btn btn-primary"
                disabled={busy}
                onClick={() => void saveUser()}
              >
                Salvar
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
