using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using OncaPDV.Application;
using OncaPDV.Domain;
using OncaPDV.Infrastructure;
using OncaPDV.Printing;

namespace OncaPDV.Desktop;

public partial class MainWindow : Window
{
    private static readonly Guid OperatorId = Guid.Parse("10000000-0000-0000-0000-000000000001");
    private readonly AppPaths _paths = AppPaths.Default();
    private readonly OncaDatabase _database;
    private readonly PosWorkflow _workflow;
    private readonly CustomerService _customers;
    private readonly IPrintService _printer;
    private readonly IReceiptRenderer _renderer = new EscPos80Renderer();
    private readonly ObservableCollection<CartRow> _rows = [];
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(1) };

    public MainWindow()
    {
        InitializeComponent();
        _database = new(_paths);
        AppServices.Database = _database;
        AppServices.Paths = _paths;
        _database.Migrate();

        var products = new SqliteProductRepository(_database);
        var sales = new SqliteSaleRepository(_database, new SystemClock());
        var customerRepository = new SqliteCustomerRepository(_database);
        _customers = new(customerRepository);
        _workflow = new(
            products,
            new JsonCartRecoveryStore(_paths),
            sales,
            new SqliteCashSessionRepository(_database, new SystemClock()),
            new SystemClock());
        _printer = new QueuedPrintService(new MockPrintService(_renderer, _paths.PrintPreview), _database);

        CartGrid.ItemsSource = _rows;
        _timer.Tick += (_, _) => ClockText.Text = DateTime.Now.ToString("ddd, dd/MM/yyyy  HH:mm:ss");
        _timer.Start();
        Loaded += OnLoaded;
    }

    private async void OnLoaded(object sender, RoutedEventArgs e)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var recovered = await _workflow.InitializeAsync();
        RefreshCart();
        await RefreshSales();
        await new OperationalService(_database, _paths).EnsureDailyBackupAsync();
        DatabaseStatus.Text = $"Banco: {_database.IntegrityCheck()} • abertura {sw.ElapsedMilliseconds} ms • backup diário OK";
        RecoveryText.Text = recovered ? "CARRINHO RECUPERADO" : string.Empty;
        SearchBox.Focus();
    }

    private async Task AddProduct()
    {
        var query = SearchBox.Text.Trim();
        if (query.Length == 0) return;

        var result = await _workflow.ScanAsync(query);
        if (result.Status == ScanStatus.DuplicateBlocked)
        {
            SetStatus("LEITURA DUPLICADA BLOQUEADA");
            return;
        }

        if (result.Status == ScanStatus.NotFound)
        {
            SetStatus("PRODUTO NÃO CADASTRADO");
            if (MessageBox.Show(
                    "PRODUTO NÃO CADASTRADO\n\nCadastrar agora?\n\nO carrinho será preservado.",
                    "ONÇA PDV",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                await OpenProduct(query, true);
            }

            SearchBox.SelectAll();
            return;
        }

        RefreshCart();
        SetStatus(result.Product!.Name);
        SearchBox.Clear();
        SearchBox.Focus();
    }

    private async Task OpenProduct(string? barcode = null, bool add = false)
    {
        var dialog = new ProductWindow(barcode) { Owner = this };
        if (dialog.ShowDialog() != true) return;

        try
        {
            await _workflow.AddProductAsync(dialog.Product!, add);
            if (add) RefreshCart();
            SetStatus("PRODUTO CADASTRADO");
        }
        catch (Exception ex) when (ex is DuplicateProductException or DomainException)
        {
            MessageBox.Show(ex.Message, "Cadastro", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        SearchBox.Focus();
    }

    private async Task CompletePaymentAsync(PaymentMethod? initialMethod = null)
    {
        if (_workflow.Cart.Items.Count == 0)
        {
            SetStatus("CARRINHO VAZIO");
            return;
        }

        var dialog = new PaymentWindow(_workflow.Cart.Total, initialMethod ?? PaymentMethod.Cash) { Owner = this };
        if (dialog.ShowDialog() != true) return;

        try
        {
            var sale = await _workflow.CompleteAsync(dialog.Payments, OperatorId);
            var printed = await _printer.PrintAsync(new(sale));
            await RefreshSales();
            RefreshCart();

            var cash = sale.Payments.Where(x => x.Method == PaymentMethod.Cash).ToArray();
            var received = cash.Sum(x => x.Received ?? x.Amount);
            var change = cash.Sum(x => x.Change);
            var cashSummary = cash.Length == 0 ? string.Empty : $"\nRecebido em dinheiro: {received:C}\nTroco: {change:C}";

            MessageBox.Show(
                $"VENDA CONCLUÍDA\n\nVenda Nº {sale.Number:000000}\nTotal: {sale.Total:C}\nPagamento: {string.Join(" + ", sale.Payments.Select(x => x.Method))}{cashSummary}\nCupom: {(printed.Success ? "OK" : "FALHOU")}",
                "ONÇA PDV",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            SetStatus("CAIXA LIVRE — PRÓXIMA VENDA");
            SearchBox.Focus();
        }
        catch (DomainException ex)
        {
            MessageBox.Show(ex.Message, "Pagamento", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private async void Pay_Click(object sender, RoutedEventArgs e) => await CompletePaymentAsync();
    private async void PayCash_Click(object sender, RoutedEventArgs e) => await CompletePaymentAsync(PaymentMethod.Cash);
    private async void PayPix_Click(object sender, RoutedEventArgs e) => await CompletePaymentAsync(PaymentMethod.Pix);
    private async void PayDebit_Click(object sender, RoutedEventArgs e) => await CompletePaymentAsync(PaymentMethod.Debit);
    private async void PayCredit_Click(object sender, RoutedEventArgs e) => await CompletePaymentAsync(PaymentMethod.Credit);
    private async void PayStoreCredit_Click(object sender, RoutedEventArgs e) => await CompletePaymentAsync(PaymentMethod.StoreCredit);

    private async void Reprint_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: Guid id }) return;
        var sale = await _workflow.GetSaleAsync(id);
        if (sale is null) return;
        var result = await _printer.PrintAsync(new(sale));
        SetStatus(result.Success ? $"VENDA {sale.Number:000000} REIMPRESSA" : result.Error ?? "FALHA");
    }

    private async void ViewSale_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: Guid id }) return;
        var sale = await _workflow.GetSaleAsync(id);
        if (sale is not null)
            new ReceiptPreviewWindow(_renderer.Render(new(sale)).Text, "Cupom 80 mm") { Owner = this }.ShowDialog();
    }

    private async void Customer_Click(object sender, RoutedEventArgs e)
    {
        var w = new CustomerSearchWindow(_customers) { Owner = this };
        if (w.ShowDialog() != true || w.Selected is null) return;
        await _workflow.SelectCustomerAsync(w.Selected.Id);
        CustomerText.Text = w.Selected.Name;
        SetStatus("CLIENTE SELECIONADO — CARRINHO PRESERVADO");
    }

    private async void RemoveCustomer_Click(object sender, RoutedEventArgs e)
    {
        await _workflow.SelectCustomerAsync(null);
        CustomerText.Text = "CONSUMIDOR";
    }

    private void CustomerManagement_Click(object sender, RoutedEventArgs e) =>
        new CustomerSearchWindow(_customers, true) { Owner = this }.ShowDialog();

    private void Credit_Click(object sender, RoutedEventArgs e) =>
        new CreditWindow(_database, OperatorId) { Owner = this }.ShowDialog();

    private void Purchases_Click(object sender, RoutedEventArgs e) =>
        new PurchasesWindow(_database) { Owner = this }.ShowDialog();

    private void Operations_Click(object sender, RoutedEventArgs e) =>
        new OperationsWindow(_database, _paths, OperatorId) { Owner = this }.ShowDialog();

    private void Preview_Click(object sender, RoutedEventArgs e)
    {
        if (_workflow.Cart.Items.Count == 0)
        {
            SetStatus("CUPOM VAZIO BLOQUEADO");
            return;
        }

        var d = new Sale(
            Guid.NewGuid(),
            0,
            DateTimeOffset.Now,
            OperatorId,
            _workflow.Cart.CustomerId,
            _workflow.Cart.Items,
            [new(PaymentMethod.Cash, _workflow.Cart.Total, _workflow.Cart.Total)],
            _workflow.Cart.Discount,
            _workflow.Cart.Total);
        new ReceiptPreviewWindow(_renderer.Render(new(d)).Text, "Prévia 80 mm") { Owner = this }.ShowDialog();
    }

    private async void Cancel_Click(object sender, RoutedEventArgs e)
    {
        if (_workflow.Cart.Items.Count == 0) return;
        if (MessageBox.Show("Cancelar explicitamente esta venda?", "ONÇA PDV", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;

        await _workflow.CancelAsync();
        RefreshCart();
        RecoveryText.Text = string.Empty;
        SetStatus("VENDA CANCELADA");
        SearchBox.Focus();
    }

    private async void CartGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
    {
        if (e.Column.DisplayIndex != 2 || e.Row.Item is not CartRow row || e.EditingElement is not TextBox box || !decimal.TryParse(box.Text, out var q))
            return;

        try
        {
            await _workflow.ChangeQuantityAsync(row.ProductId, q);
            _ = Dispatcher.BeginInvoke(RefreshCart);
        }
        catch (DomainException ex)
        {
            MessageBox.Show(ex.Message);
            _ = Dispatcher.BeginInvoke(RefreshCart);
        }
    }

    private async Task RefreshSales() => SalesGrid.ItemsSource = await _workflow.LastSalesAsync();

    private void RefreshCart()
    {
        _rows.Clear();
        foreach (var i in _workflow.Cart.Items)
            _rows.Add(new(i.ProductId, i.Code, i.Name, i.Quantity, i.UnitPrice, i.Subtotal));
        TotalText.Text = _workflow.Cart.Total.ToString("C");
    }

    private void SetStatus(string value) => StatusText.Text = value;

    private async void Add_Click(object sender, RoutedEventArgs e) => await AddProduct();

    private async void SearchBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter) return;
        e.Handled = true;
        await AddProduct();
    }

    private async void Product_Click(object sender, RoutedEventArgs e) => await OpenProduct();
    private void Printer_Click(object sender, RoutedEventArgs e) => new PrinterSettingsWindow(_paths) { Owner = this }.ShowDialog();
    private void Diagnostic_Click(object sender, RoutedEventArgs e) => new DiagnosticWindow(new DiagnosticService(_database, _paths)) { Owner = this }.ShowDialog();

    private void Window_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.F1) Product_Click(sender, e);
        else if (e.Key == Key.F2) Pay_Click(sender, e);
        else if (e.Key == Key.Escape) Cancel_Click(sender, e);
    }

    private sealed record CartRow(Guid ProductId, string Code, string Name, decimal Quantity, decimal UnitPrice, decimal Subtotal);
}
